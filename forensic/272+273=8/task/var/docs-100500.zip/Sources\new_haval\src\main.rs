use core::time::Duration;
use std::fmt::Debug;
use std::thread;

use opencv::boxed_ref::BoxedRef;
use opencv::core::{AlgorithmHint, DataType, Mat, MatTraitConst, Range, VecN, Vector};
use opencv::{highgui, imgproc};
use scap::capturer::{Capturer, Options};
use scap::frame::{BGRAFrame, Frame, FrameType};

trait MatExt
where
    Self: Sized,
{
    fn slice(&self, x_from: i32, x_to: i32, y_from: i32, y_to: i32) -> Result<Self, opencv::Error>;
    fn convert(&self, code: i32, dst_pixel_type: i32) -> Result<Self, opencv::Error>;
    fn from_raw<T: DataType + Copy + Debug, const CHANNELS: usize>(
        width: i32,
        height: i32,
        raw: &[T],
    ) -> Result<Self, opencv::Error>;
}

impl MatExt for Mat {
    fn slice(&self, x_from: i32, x_to: i32, y_from: i32, y_to: i32) -> Result<Self, opencv::Error> {
        let ranges = Vector::from_iter(
            [
                Range::new(y_from, y_to).unwrap(),
                Range::new(x_from, x_to).unwrap(),
            ]
            .into_iter(),
        );

        Ok(self.ranges(&ranges)?.clone_pointee())
    }

    fn convert(&self, code: i32, dst_pixel_type: i32) -> Result<Self, opencv::Error> {
        let mut dst_mat =
            unsafe { Mat::new_rows_cols(self.rows(), self.cols(), dst_pixel_type).unwrap() };

        imgproc::cvt_color(
            self,
            &mut dst_mat,
            code,
            0,
            AlgorithmHint::ALGO_HINT_DEFAULT,
        )?;

        Ok(dst_mat)
    }

    fn from_raw<T: DataType + Copy + Debug, const CHANNELS: usize>(
        width: i32,
        height: i32,
        raw: &[T],
    ) -> Result<Self, opencv::Error> {
        let pixels = raw
            .chunks(CHANNELS)
            .map(|channels| {
                VecN::<T, CHANNELS>::from(<[T; CHANNELS]>::try_from(channels.to_owned()).unwrap())
            })
            .collect::<Vec<_>>();

        Ok(Mat::new_rows_cols_with_data(height, width, &*pixels)?.clone_pointee())
    }
}

fn main() {
    if !scap::is_supported() {
        panic!("Fuckingly, screen capture is not supported");
    }

    if !scap::has_permission() {
        panic!("WTF is a screen capture permission?");
    }

    let targets = scap::get_all_targets();

    let telegram_desktop = targets.into_iter().find(|target| match target {
        scap::Target::Window(window) => window.title == "TelegramDesktop",
        scap::Target::Display(_) => false,
    });

    let mut capturer = Capturer::build(Options {
        fps: 1,
        show_cursor: false,
        show_highlight: false,
        output_type: FrameType::RGB,
        target: Some(telegram_desktop.expect("there should be a Telegram Web View window")),
        ..Default::default()
    })
    .unwrap();

    capturer.start_capture();

    loop {
        // let frame = capturer.get_next_frame().unwrap();

        // process_frame(match frame {
        //     Frame::BGRA(frame) => frame,
        //     _ => panic!("Surprisingly, frame type is not BGRA"),
        // });

        // process_frame();

        // thread::sleep(Duration::from_secs(1) / 60);

        // highgui::poll_key().unwrap();
    }
}

fn get_rgb_mat_from_frame() -> Mat {
    let bgra = Mat::from_raw::<u8, 4>(1920, 1080, &*vec![0u8; (1920 * 1080 * 4) as usize]).unwrap();
    let rgb = bgra
        .convert(imgproc::COLOR_BGRA2RGB, opencv::core::CV_8UC3)
        .unwrap();

    rgb
}

fn process_frame() {
    let _window = get_rgb_mat_from_frame();

    // let game = window
    //     .slice(10, window.cols() - 10, 70, window.rows() - 52)
    //     .unwrap();

    // highgui::imshow("Haval?", &window).unwrap();
}
